document.addEventListener("DOMContentLoaded", checkToken);

function checkToken() {
  const token = getTokenFromCookie();

  if (!token) {
    redirectToLoginPage();
  } else {
    fetchDataWithToken(token);
  }
}

function getTokenFromCookie() {
  const cookies = document.cookie.split("; ");
  for (const cookie of cookies) {
    const [name, value] = cookie.split("=");
    if (name === "token") {
      return value;
    }
  }
  return null;
}

function fetchDataWithToken(token) {
  // Make an API call using the token
  fetch("http://localhost:3000/favouriteMovies/get_movies", {
    method: "GET",
    headers: {
      Authorization: `Bearer ${token}`,
    },
  })
    .then((response) => response.json())
    .then((data) => {
      console.log(data);
      // Process and display the fetched data on the dashboard
      populateItemTable(data);
    })
    .catch((error) => {
      console.error("Error fetching data:", error);
    });
}

function populateItemTable(items) {
    const tableBody = document.querySelector("#item-table tbody");
  
    items.forEach((item) => {
      const row = createTableRow(item);
      row.dataset.id = item._id; // Set the data-id attribute
      tableBody.appendChild(row);
    });
  }
  
  
  function createTableRow(item) {
    const row = document.createElement("tr");
  
    const properties = [
      "Title", "Year", "Genre", "Director",
      // Add more property names as needed
    ];
  
    properties.forEach(property => {
      const cell = createCustomTableCell(item[property]);
      row.appendChild(cell);
    });
  
    const actionCell = createCustomActionCell(item._id);
    row.appendChild(actionCell);
  
    return row;
  }
  
  function createCustomTableCell(text) {
    const cell = document.createElement("td");
    cell.textContent = text;
    return cell;
  }
  
  function createCustomActionCell(itemId) {
    const actionCell = document.createElement("td");
  
    const editButton = document.createElement("button");
    editButton.classList.add("edit-button");
    editButton.textContent = "Edit";
    editButton.dataset.id = itemId;
    editButton.addEventListener("click", () => editItem(itemId));
  
    const deleteButton = document.createElement("button");
    deleteButton.classList.add("delete-button");
    deleteButton.textContent = "Delete";
    deleteButton.dataset.id = itemId;
    deleteButton.addEventListener("click", () => deleteItem(itemId));
  
    actionCell.appendChild(editButton);
    actionCell.appendChild(deleteButton);
  
    return actionCell;
  }
  
  
function redirectToLoginPage() {
  window.location.href = "index.html";
}

const logoutLink = document.querySelector(".sidebar ul li:last-child a");
logoutLink.addEventListener("click", handleLogout);

function handleLogout(event) {
  event.preventDefault();

  clearTokenCookie();
  redirectToLoginPage();
}

function clearTokenCookie() {
  document.cookie = "token=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;";
}

function editItem(itemId) {
    // Construct the edit page URL with the itemId as a query parameter
    const editPageUrl = `edit.html?id=${itemId}`;
    // Navigate to the edit page
    window.location.href = editPageUrl;
}

function deleteItem(itemId) {
    const token = getTokenFromCookie();
  
    if (!token) {
      redirectToLoginPage();
      return;
    }
  
    fetch(`http://localhost:3000/favouriteMovies/delete_movie/${itemId}`, {
      method: "DELETE",
      headers: {
        Authorization: `Bearer ${token}`,
      },
    })
      .then((response) => {
        if (response.ok) {
          // Remove the deleted item from the table and update UI
          const deletedRow = document.querySelector(`tr[data-id="${itemId}"]`);
          if (deletedRow) {
            deletedRow.remove();
          }
        } else {
          console.error("Failed to delete item.");
        }
      })
      .catch((error) => {
        console.error("Error deleting item:", error);
      });
  }  