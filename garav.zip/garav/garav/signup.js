const signupForm = document.getElementById("signup-form");
const errorMessage = document.getElementById("error-message1");

signupForm.addEventListener("submit", handleSignup);

function handleSignup(event) {
  event.preventDefault();

  const username = document.getElementById("username").value;
  const email = document.getElementById("email").value;
  const password = document.getElementById("password").value;
  const confirmPassword = document.getElementById("confirm-password").value;

  clearErrorMessage();

  if (!validateFields(username, email, password, confirmPassword)) {
    return;
  }

  registerUser(username, email, password);
}

function clearErrorMessage() {
  errorMessage.textContent = "";
}

function validateFields(username, email, password, confirmPassword) {
  if (username.trim() === "" || email.trim() === "" 
  || password.trim() === "" || confirmPassword.trim() === "") {
    errorMessage.textContent = "Please fill in all fields.";
    return false;
  }

  if (password !== confirmPassword) {
    errorMessage.textContent = "Passwords do not match.";
    return false;
  }

  return true;
}

async function registerUser(username, email, password) {
  try {
    const response = await fetch("http://localhost:3000/favouriteMovies/user_register", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({"userName": username,"email": email,"password": password }),
    });

    const data = await response.json();

    if (response.ok) {
      redirectToLoginPage();
    } else {
      errorMessage.textContent = data.message; // Replace with the actual error message field in your response
    }
  } catch (error) {
    errorMessage.textContent = "An error occurred. Please try again later.";
    console.error(error);
  }
}

function redirectToLoginPage() {
  window.location.href = "index.html";
}
