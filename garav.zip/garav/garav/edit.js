document.addEventListener("DOMContentLoaded", () => {
    const itemId = getQueryStringParameter("id");
    if (itemId) {
      populateEditForm(itemId);
    }
  });
  
  function getQueryStringParameter(name) {
    const urlParams = new URLSearchParams(window.location.search);
    return urlParams.get(name);
  }
  
  async function populateEditForm(itemId) {
    const token = getTokenFromCookie();
    if (!token) {
      redirectToLoginPage();
      return;
    }
  
    try {
      const editForm = document.getElementById("edit-form");
      const item = await fetchItem(itemId, token);
      if (item) {
        for (const property in item) {
            if (item.hasOwnProperty(property)) {
              const label = createLabel(property);
              const input = createInputField(property, item[property]);
              editForm.appendChild(label);
              editForm.appendChild(input);
            }
          }

          const submitButton = document.createElement("button");
          submitButton.type = "submit";
          submitButton.textContent = "Save Changes";
          editForm.appendChild(submitButton);
       
      } else {
        console.error("Item not found.");
      }
    } catch (error) {
      console.error("Error fetching item:", error);
    }
  }
  function createLabel(key) {
    const label = document.createElement("label");
    label.textContent = key.charAt(0).toUpperCase() + key.slice(1); // Capitalize the first letter
    label.setAttribute("for", key);
    return label;
  }

  function createInputField(name, value) {
    const input = document.createElement("input");
    input.setAttribute("type", "text");
    input.setAttribute("name", name);
    input.setAttribute("value", value);
    return input;
  }
 
  
  async function fetchItem(itemId, token) {
    const response = await fetch(`http://localhost:3000/favouriteMovies/get_movie/${itemId}`, {
      headers: {
        Authorization: `Bearer ${token}`
      }
    });
    
    if (response.ok) {
      const data = await response.json();
      return data;
    } else {
      return null;
    }
  }
  function getTokenFromCookie() {
    const cookies = document.cookie.split("; ");
    for (const cookie of cookies) {
      const [name, value] = cookie.split("=");
      if (name === "token") {
        return value;
      }
    }
    return null;
  }
  
  
  // Handle form submission
  const editForm = document.getElementById("edit-form");
  editForm.addEventListener("submit", async (event) => {
    event.preventDefault();
    const token = getTokenFromCookie();
    
    if (!token) {
      redirectToLoginPage();
      return;
    }
  
    const itemId = getQueryStringParameter("id");
    const formData = new FormData(editForm);
    const formDataObject = {};
    for (const [key, value] of formData.entries()) {
      formDataObject[key] = value;
    }
    try {
      const response = await fetch(`http://localhost:3000/favouriteMovies/update_movie/${itemId}`, {
        method: "PUT",
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json"
        },
        body: JSON.stringify(formDataObject) 
      });
  
      if (response.ok) {
        // Successfully updated, redirect to dashboard or item details page
        window.location.href = "home.html";
      } else {
        console.error("Failed to update item.");
      }
    } catch (error) {
      console.error("Error updating item:", error);
    }
  });

  