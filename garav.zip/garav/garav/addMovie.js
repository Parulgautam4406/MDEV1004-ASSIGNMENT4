document.addEventListener("DOMContentLoaded", () => {
    const addItemForm = document.getElementById("add-form");
  
    // Iterate over the properties in the schema and create input fields
    for (const property in schema) {
      const label = document.createElement("label");
      label.textContent = property + ":";
  
      const input = document.createElement("input");
      input.type = "text";
      input.name = property;
      input.required = true;
  
      addItemForm.appendChild(label);
      addItemForm.appendChild(input);
    }
     // Append a submit button to the form
    const submitButton = document.createElement("button");
    submitButton.type = "submit";
    submitButton.textContent = "Add Item";
    addItemForm.appendChild(submitButton);

    addItemForm.addEventListener("submit", async (event) => {
      event.preventDefault();
      const token = getTokenFromCookie();
    
      if (!token) {
        redirectToLoginPage();
        return;
      }
  
      const formData = new FormData(addItemForm);
       // Convert the FormData to a plain object
      const formDataObject = {};
      for (const [key, value] of formData.entries()) {
        formDataObject[key] = value;
      }
      try {
        const response = await fetch("http://localhost:3000/favouriteMovies/add_movie", {
          method: "POST",
          headers: {
            Authorization: `Bearer ${token}`,
            "Content-Type": "application/json"
          },
          body: JSON.stringify(formDataObject) 
        });
  
        if (response.ok) {
          // Successfully added, redirect to dashboard or item list page
          window.location.href = "home.html"
        } else {
          console.error("Failed to add item.");
        }
      } catch (error) {
        console.error("Error adding item:", error);
      }
    });
  });
  
  function getTokenFromCookie() {
    const cookies = document.cookie.split("; ");
    for (const cookie of cookies) {
      const [name, value] = cookie.split("=");
      if (name === "token") {
        return value;
      }
    }
    return null;
  }
  
  function redirectToLoginPage() {
    window.location.href = "index.html";
  }
  
  const schema = {
    Title: "",
    Year: "",
    Rated: "",
    Released: "",
    Runtime: "",
    Genre: "",
    Director: "",
    Writer: "",
    Actors: "",
    Plot: "",
    Language: "",
    Country: "",
    Awards: "",
    Poster: "",
    Metascore: "",
    imdbRating: "",
    imdbVotes: "",
    imdbID: "",
    Type: "",
    Response: "",
    Images: ""
  };