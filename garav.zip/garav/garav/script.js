const loginForm = document.getElementById("login-form");
const errorMessage = document.getElementById("error-message");
const passwordInput = document.getElementById("password");


loginForm.addEventListener("submit", handleLogin);

function handleLogin(event) {
  event.preventDefault();

  const username = document.getElementById("username").value;
  const password = passwordInput.value;

  clearErrorMessage();
  
  if (!validateFields(username, password)) {
    return;
  }

  attemptLogin(username, password);
}

function clearErrorMessage() {
  errorMessage.textContent = "";
}

function validateFields(username, password) {
  if (username.trim() === "" || password.trim() === "") {
    errorMessage.textContent = "Please fill in all fields.";
    return false;
  }
  return true;
}

async function attemptLogin(username, password) {
  try {
    const response = await fetch("http://localhost:3000/favouriteMovies/user_login", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({"email": username, "password":password }),
    });

    const data = await response.json();

    if (response.ok) {
      handleSuccessfulLogin(data.token);
    } else {
      handleFailedLogin(data.message);
    }
  } catch (error) {
    handleLoginError();
    console.error(error);
  }
}

function handleSuccessfulLogin(token) {
  setTokenCookie(token);
  redirectToHomePage();
}

function setTokenCookie(token) {
  const expirationHours = 1; // Change this value to the desired expiration time in hours
  const expirationDate = new Date();
  expirationDate.setTime(expirationDate.getTime() + expirationHours * 60 * 60 * 1000);
  document.cookie = `token=${token}; expires=${expirationDate.toUTCString()}; path=/;`;
}

function redirectToHomePage() {
  window.location.href = "home.html";
}

function handleFailedLogin(message) {
  errorMessage.textContent = message;
}

function handleLoginError() {
  errorMessage.textContent = "An error occurred. Please try again later.";
}
